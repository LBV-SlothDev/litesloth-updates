# LiteSloth Scrawl

A simple programming language from LiteSloth. Easy to read and write, and it
turns your program into a small, fast Go program.

```
note: my first LiteSloth Scrawl program
write "Hello, world!"
set name to ask "What's your name? "

Let.Greet (person)
    write "Hello, " + person

Let.Greet (name)
```

## Try it

On a Mac (or Linux), install with `sh install.sh` in this folder: it builds `scrawl` on your own
computer (so the Mac doesn't block it) and puts it in `~/bin`. Release zips also come with a
ready-made `scrawl` for Windows and Linux in `bin/`.
Scrawl uses Go to make programs; if Go isn't on the computer, Scrawl downloads the
official copy from go.dev the first time (about 70 MB, checked, kept in `~/.scrawl`).
`scrawl setup` does that ahead of time.

To build `scrawl` yourself from this code instead, use [Go](https://go.dev/dl) 1.22 or newer:

```
go build -o scrawl ./cmd/scrawl
./scrawl run examples/calculator.scrawl
```

| Command | What it does |
|---|---|
| `scrawl run file.scrawl` | run a program |
| `scrawl build file.scrawl -o name` | make a program file you can share (one small file, no extras needed); `-o Name.app` makes a Mac app |
| `scrawl build file.scrawl --for windows` | the same for another kind of computer: `linux`, `windows`, `mac`, `mac-arm` (and `-arm` for Linux and Windows) |
| `scrawl check file.scrawl` | look for mistakes without running |
| `scrawl test file.scrawl` | run the `Test.` commands and say which passed |
| `scrawl check --json file.scrawl` | the same, as JSON for editors |
| `scrawl tidy file.scrawl` | line up indentation and spacing neatly |
| `scrawl go file.scrawl` | show the Go code your program becomes |
| `scrawl get <link>` / `scrawl libraries` | add a shared library / list your libraries |
| `scrawl setup` | get Go if it's missing (otherwise done for you the first time) |

Examples are in [`examples/`](examples). All the words are in [WORDS.md](WORDS.md).

## Friendly errors

```
calculator.scrawl, Line 2: I don't know "seed". Did you mean "seeds"?
```

## Status: version 0.11

Works now: write, set, ask, Let. commands, give back, if / otherwise if /
otherwise, repeat N times / until / forever, each, stop, skip, try / otherwise,
lists, Thing. (things with parts), files, on/off, notes, math with symbols or
words, list/text/number dot actions, `bring in "other-file.scrawl"` to
split a program into files (see [`examples/shop`](examples/shop)), Python
libraries like pandas (`bring in pandas`, see [`examples/data`](examples/data)),
web servers with `Route.` and a database (see [`examples/academy`](examples/academy)),
`web.get` / `web.post` for other websites' APIs, and **web pages** with
`Page.`, `show`, `remember`, `when clicked` and `Style.` that update by themselves
(see [`examples/webshop`](examples/webshop)), and whole websites with shared
parts (`Part.`), your own files (`server.files`), scripts and effects, a full set
of style words with hover / dark / phone versions, and accounts
(`bring in accounts`, see [`examples/site`](examples/site)), plus everyday helpers:
lookups, random numbers, dates and times, and more list, text and number actions
(see [`examples/everyday.scrawl`](examples/everyday.scrawl)), `raw go:` / `raw python:`
blocks for the rare things Scrawl has no word for (see [`examples/raw.scrawl`](examples/raw.scrawl)),
`scrawl tidy`, desktop apps (`app.start`, and `-o Name.app` on a Mac), `at the same time`, things with their
own commands and marked values (see [`examples/pets.scrawl`](examples/pets.scrawl)), files and folders,
libraries (`scrawl get`), and pages with tabs, charts, maps, dates, lookups and your own `Let.` commands
(see [`examples/dashboard`](examples/dashboard)), and SQLite databases with plain SQL
(`bring in database "shop" as sqlite` and `db.sql`, see [`examples/sqlite.scrawl`](examples/sqlite.scrawl);
run `scrawl setup sqlite` once first), channels for jobs that run at the same time
(see [`examples/channels.scrawl`](examples/channels.scrawl)), Things built on other Things
(`Thing.Dog is a Pet (tricks)`, see [`examples/family.scrawl`](examples/family.scrawl)), pages that switch
without reloading, and a step-through debugger in Space Coder (F5, or `scrawl debug`).
New in 0.10: checks before running (misspelled parts of Things, actions text and numbers don't have, math with
text), built-in tests (`Test.`, `expect`, `scrawl test`, with a fresh database), forms and tables on pages
(`show checkbox`, `notes`, `number`, `choice`, `table`), and `scrawl build --for` Windows, Linux and Mac.
New in 0.11: fingerprints and digital signatures with `secure.hash`, `secure.keys`, `secure.sign`,
`secure.check` and `secure.random`, using Go's standard crypto (see [`examples/tiny-chain.scrawl`](examples/tiny-chain.scrawl),
a tiny blockchain).

The biggest example is [`examples/calendar`](examples/calendar): **Pure Calendar**, the LiteSloth OS calendar
(month, week and day views, colored events with times, notes, repeats, search, reminders, dragging, Google
Calendar import, light and dark, saved in SQLite, with tests: `scrawl test main.scrawl`).

Speed: Scrawl works out by itself which names always hold numbers, text or
on/off and turns them into plain Go, so a 10-million-step loop runs in about
30 ms (Python: about 900 ms). Names that hold different kinds of values still
work, using flexible values.

The editor is LiteSloth Space Coder (see [`spacecoder`](spacecoder)).

Servers serve many visitors at once, and the database saves by adding one line
to a change log, so it stays fast with lots of data and survives a crash mid-save.

## How it works

`compiler/` reads your `.scrawl` file and writes Go code. `rt/` is the small
runtime every program uses. `cmd/scrawl/` is the command. `scrawl run` builds
the Go code into a program and runs it.

## License

MIT, see [LICENSE](LICENSE).
