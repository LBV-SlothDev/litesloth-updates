(function () {
  var root = window.SCRAWL_ROOT || "";
  var html = document.documentElement;
  // light / dark: follows the computer, or the reader's choice (when this page may remember it)
  function saved() { try { return localStorage.getItem("scrawl-theme"); } catch (e) { return null; } }
  if (saved()) html.setAttribute("data-theme", saved());
  var themeBtn = document.querySelector(".theme");
  if (themeBtn) themeBtn.onclick = function () {
    var dark = html.getAttribute("data-theme") ? html.getAttribute("data-theme") === "dark"
      : window.matchMedia("(prefers-color-scheme: dark)").matches;
    var next = dark ? "light" : "dark";
    html.setAttribute("data-theme", next);
    try { localStorage.setItem("scrawl-theme", next); } catch (e) {}
  };
  // menu on phones
  var menu = document.querySelector(".menu");
  if (menu) menu.onclick = function () { document.body.classList.toggle("nav"); };
  // copy buttons on code
  document.querySelectorAll("pre.code").forEach(function (pre) {
    var b = document.createElement("button");
    b.className = "copy"; b.type = "button"; b.textContent = "Copy";
    b.onclick = function () {
      var text = pre.querySelector("code").innerText;
      var done = function () { b.textContent = "Copied"; setTimeout(function () { b.textContent = "Copy"; }, 1500); };
      if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, function () { b.textContent = "Select and copy"; });
      else b.textContent = "Select and copy";
    };
    pre.appendChild(b);
  });
  // search across page titles and headings
  var input = document.querySelector(".search input"), box = document.querySelector(".results"), index = null;
  function load(cb) {
    if (index) return cb();
    if (window.SCRAWL_SEARCH) { index = window.SCRAWL_SEARCH; return cb(); }
    fetch(root + "search.json").then(function (r) { return r.json(); }).then(function (j) { index = j; cb(); })
      .catch(function () { index = []; cb(); });
  }
  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function run() {
    var q = input.value.trim().toLowerCase();
    if (!q) { box.classList.remove("show"); return; }
    load(function () {
      var hits = [];
      index.forEach(function (p) {
        if (p.t.toLowerCase().indexOf(q) >= 0) hits.push({ t: p.t, u: p.u, s: "Page" });
        p.h.forEach(function (h) { if (h[0].toLowerCase().indexOf(q) >= 0) hits.push({ t: h[0], u: p.u + "#" + h[1], s: p.t }); });
      });
      box.innerHTML = hits.slice(0, 12).map(function (h) {
        return '<a href="' + root + h.u + '">' + esc(h.t) + "<small>" + esc(h.s) + "</small></a>";
      }).join("") || '<a>No matches<small>Try a word like "list" or "page"</small></a>';
      box.classList.add("show");
    });
  }
  if (input) {
    input.addEventListener("input", run);
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { var a = box.querySelector("a[href]"); if (a) location.href = a.href; }
      if (e.key === "Escape") { input.value = ""; run(); }
    });
    document.addEventListener("click", function (e) { if (!e.target.closest(".search")) box.classList.remove("show"); });
  }
})();
