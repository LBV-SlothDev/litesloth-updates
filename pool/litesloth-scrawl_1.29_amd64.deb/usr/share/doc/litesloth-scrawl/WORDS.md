# LiteSloth Scrawl words (version 0.7)

Blocks end by indentation (4 spaces is normal). Notes start with `note:`.

## Basics
| Word | Example |
|---|---|
| Show something | `write "Hello"` |
| Store a value | `set seeds to 10` |
| Ask the user | `set name to ask "Your name? "` |
| Text to number | `set age to answer.number ()` |
| Join text | `"Hello, " + name` (numbers join as text too) |
| Math | `+ - * /` or `plus minus times divided by` |
| Yes/no | `on` / `off` |
| No value | `nothing` (like `if learner is nothing`) |
| Note | `note: this is a note` |

## Choices
```
if seeds is more than 12
    write "You can buy a hat!"
otherwise if seeds is more than 5
    write "Almost there!"
otherwise
    write "Keep saving."
```
Checks: `is`, `is not`, `is more than`, `is less than`, `is at least`, `is at most`.
Combine with `and`, `or`, `not`.

## Loops
```
repeat 4 times
repeat until seeds is at least 100
repeat forever
each fruit in fruits
```
Inside a loop: `stop` leaves the loop, `skip` jumps to the next round.

## Your own commands
```
Let.Double (number)
    give back number times 2

write Let.Double (21)
```
Names you `set` inside a command are its own, except names the program already made at the top:
setting one of those changes it for everyone.
```
set score to 0
Let.Win ()
    set score to score + 10
Let.Win ()
write score
```
Say what kind of value a command needs with `as`, and Scrawl checks it (before running when it can):
```
Let.Add (a as number, b as number)
    give back a + b
```
Kinds: `number`, `text`, `on/off`, `list`, `lookup`, `date`, or a Thing name like `Pet`.

## Things with parts
```
Thing.Player (name, score)
set p to Thing.Player ("Charlie", 10)
set p.score to p.score + 5
write p.name
```
A thing can have its own commands. Inside, `my` is the thing itself:
```
Thing.Pet (name, age)
Let.Pet.Birthday ()
    set my.age to my.age + 1
    give back my.name + " is now " + my.age

set charlie to Thing.Pet ("Charlie", 3)
write charlie.Birthday ()
```
A saved thing has a number: `learner.id`.

A Thing can be built on another one. It gets all of that Thing's parts (first) and commands, and can add its own:
```
Thing.Pet (name, age)
Thing.Dog is a Pet (tricks)

Let.Pet.Speak ()
    give back my.name + " makes a sound"
Let.Dog.Speak ()
    give back my.name + " says woof"

set rex to Thing.Dog ("Rex", 4, list "sit")
write rex.speak ()
write rex.kind ()
```
This writes "Rex says woof" (a Dog's own Speak comes first) and "Dog".
A Dog counts as a Pet for commands that ask for one, like `Let.Pet.Birthday ()` or `Let.Introduce (pet as Pet)`.
`db.find (Thing.Dog)` finds Dogs; `db.find (Thing.Pet)` finds things made as Pets.

## Lists
`set fruits to list "apple", "kiwi"`

| Action | Example |
|---|---|
| add / remove | `fruits.add ("mango")`, `fruits.remove ("kiwi")` |
| count / has | `fruits.count ()`, `fruits.has ("kiwi")` |
| sort / reverse | `fruits.sort ()`, `fruits.reverse ()`, and for things or lookups by a part: `events.sort ("start")` |
| first / last / item | `fruits.first ()`, `fruits.item (2)` (counting starts at 1) |
| join | `fruits.join (", ")` |
| total / average | `scores.total ()`, `scores.average ()` |
| biggest / smallest | `scores.biggest ()`, `scores.smallest ()` |
| shuffle | `cards.shuffle ()` (mixes the order) |
| part | `scores.part (2, 3)` (items 2 to 3 as a new list) |
| position | `fruits.position ("kiwi")` (where it is, or 0 if it isn't there) |

## Lookups (names that point to values)
```
set prices to lookup "apple" is 2, "kiwi" is 3
prices.set ("mango", 5)
write prices.item ("mango")
set prices.kiwi to 4
each fruit in prices
    write fruit + " costs " + prices.item (fruit)
```
`set empty to lookup` makes an empty one. Actions: `item (name)` (or `nothing` if it isn't there),
`set (name, value)`, `has (name)`, `remove (name)`, `count ()`, `keys ()`, `values ()`.
`prices.kiwi` works too when the name is a plain word. Names are text (numbers turn into text), and they
keep the order you added them in. Lookups become JSON objects when a Route. gives one back.

## Text
`number ()`, `upper ()`, `lower ()`, `count ()`, `has ("x")`, `split (",")`, `trim ()`, `replace ("a", "b")`,
`starts ("char")`, `ends ("sloth")`, `position ("sloth")` (or 0), `part (1, 7)` (letters 1 to 7),
`repeat (3)`, `capital ()` (first letter big), `letters ()` (a list of letters), `lines ()` (a list of lines)

## Numbers
`text ()`, `text (2)` (always 2 decimals: 3.50), `commas ()` (1,234,567), `commas (2)` (1,234.50),
`round ()`, `round (2)`, `roundup ()`, `rounddown ()`, `positive ()` (drops the minus), `root ()` (square root), `power (2)`

## Random
`random.number (1, 6)` gives a whole number from 1 to 6. `random.pick (fruits)` picks one item. `fruits.shuffle ()` mixes a list.

## Dates and times
```
set christmas to time.date ("2026-12-25")
set today to time.today ()
write today.until (christmas, "days") + " days to go"
set reminder to time.now ().add (2, "hours")
write reminder.clock ()
```
- Make one: `time.now ()` (right now), `time.today ()` (today at midnight), `time.date ("2026-12-25")` or `time.date ("2026-12-25 18:30")`. Dates written by hand work too: `"12/25/2026"` (month first), `"Dec 25, 2026"`, `"25 December 2026"`, and 12-hour times like `"Dec 25, 2026 6:30 PM"` or `"2026-12-25 01:24pm"`. A time on its own, like `"1:24pm"`, is today.
- Parts: `year ()`, `month ()`, `day ()`, `hour ()`, `minute ()`, `second ()`, `weekday ()` (Friday), `monthname ()` (December).
- Show: `date ()` (Dec 25, 2026), `clock ()` (6:30 PM), `text ()`, or your own pattern: `text ("weekday, monthname day, year")` (also hour, minute, second, ampm).
- Math: `add (3, "days")` (seconds, minutes, hours, days, weeks, months, years; a minus number goes back), `until (other, "days")` (whole units), `ago ()` (3 days ago, in 2 hours, just now).
- Compare: `if christmas is more than today`.
- Wait: `time.wait (2)` pauses for 2 seconds.
- Dates, lookups, `random` and all the list, text and number actions work on pages too.

## Files and folders
```
file.save ("notes.txt", text)
set text to file.open ("notes.txt")
file.add ("log.txt", "Took a nap")
```
- Files: `file.save`, `file.open`, `file.add` (adds a line at the end), `file.exists`, `file.delete`,
  `file.copy ("a.txt", "b.txt")`, `file.move ("a.txt", "old")` (into a folder, or a new name), `file.size`, `file.changed` (a date).
- Folders: `folder.list ("photos")` (folders end with /), `folder.make`, `folder.exists`, `folder.delete` (empty folders only), `folder.here ()`.
- Copy and move never write over a file that's already there.

## Splitting a program into files
```
bring in "money.scrawl"
bring in "parts/items.scrawl"
```
The file name is found next to the file that brings it in. A brought-in file
holds `Let.` commands and `Thing.`s (and can bring in other files). Bringing in
the same file twice is fine; it's only read once.

## Libraries (code other people share)
```
scrawl get https://example.com/charts.scrawl
```
That keeps a copy in your libraries, and then any program can use it with `bring in "charts"`.
`scrawl libraries` lists the ones you have. GitHub links work too. Only get libraries from people you trust,
because a library runs like your own code.

## Python libraries
```
bring in pandas
set sales to pandas.read_csv ("sales.csv")
write sales.item ("seeds").sum ()
```
`bring in` a name without quotes uses a Python library (Python must be
installed). Dotted names work too: `bring in matplotlib.pyplot` gives you
`pyplot`. `x.item ("seeds")` is Python's `x["seeds"]`. Python mistakes show up
as Scrawl problems you can catch with `try`.

## Web servers
```
Route.Get ("/api/learners/{name}")
    set learner to db.first (Thing.Learner, name is request.name)
    if learner is nothing
        give back error 404, "No learner called " + request.name
    give back learner

server.start (8080)
```
- `Route.Get`, `Route.Post`, `Route.Put`, `Route.Delete` with the address in quotes. `{name}` in the address is filled in from the link.
- `request.amount` reads what was sent: the address, then the JSON body, then `?amount=` in the link. If it's missing, the answer is a 400 error.
- `give back x` answers with x as JSON. `give back error 400, "message"` answers with an error.
- A problem inside a route answers with error 500 and the server keeps running.
- Many visitors are served at once. Scrawl code takes turns, but while one visitor waits (for `web.get`,
  `time.wait`, or a password check), the others carry on. A route can change top-level names, like a visit counter.

## Databases
```
bring in database "academy"
Thing.Learner (name, seeds)

db.save (learner)
db.delete (learner)
set all to db.find (Thing.Learner)
set rich to db.find (Thing.Learner, seeds is at least 50)
set one to db.first (Thing.Learner, name is "Charlie")
```
Inside `db.find` / `db.first` / `db.count`, the thing's parts (like `seeds`) and its number (`id`) can be used by
name, like `db.first (Thing.Learner, id is 3)`. `db.first` gives `nothing` when there's no match. `db.count (Thing.Learner, seeds is at least 50)`
counts matches. A saved thing has a number: `learner.id`.

The data is kept in two files next to the program: `academy.scrawldb.json` (a full copy) and
`academy.scrawldb.log` (each change since then). Saving only adds one line, so it stays fast
with lots of data, and if the computer stops in the middle of a save, the rest is safe.

### SQLite (for big programs)
```
bring in database "shop" as sqlite
Thing.Item (name, price)

db.save (Thing.Item ("Seed pack", 3))
set cheap to db.find (Thing.Item, price is less than 5)
set rows to db.sql ("select name, price from Item where price < ? order by price", 5)
each row in rows
    write row.name + " costs " + row.price
db.sql ("create table if not exists notes (words text)")
```
Add `as sqlite` and the database is kept in `shop.sqlite`, a real SQLite database that stays fast with
millions of records and is safe when many visitors save at once. All the words above (`db.save`, `db.find`,
`db.first`, `db.count`, `db.delete`) work the same.

- Run `scrawl setup sqlite` once first (it needs the internet that one time). After that, programs build without it.
- `db.sql ("...", values)` runs plain SQL. Put `?` where a value goes and give the values after it.
  Questions (`select ...`) give back a list of lookups, one per row. Changes (`update`, `delete`, `insert`, `create`)
  give back how many rows changed.
- Each `Thing.` kind can be asked about by its name, like `select name from Item`, with one column per part plus `id`.
- If the program had a `shop.scrawldb.json` database before, its records move into `shop.sqlite` by themselves
  the first time (the old file is kept).

## Talking to other websites
```
set learners to web.get ("https://example.com/api/learners")
web.post ("https://example.com/api/seeds", learner)
```
JSON answers become lists and things you can use with dots (`l.name`).

## Web pages
```
Page.Shop ("/shop")
    remember seeds as 120
    remember items as server.get ("/api/items")
    remember name as ""

    show heading "Seeds Shop"
    show text "You have " + seeds + " seeds" style Price
    show input "Your name" into name
    show button "Get 10 free seeds"
        when clicked
            set seeds to seeds + 10
            write "Here you go, " + name
    show row
        each item in items
            show card item.name
                show picture item.picture
                show button "Buy for " + item.price
                    when clicked
                        server.post ("/api/buy", item)
                        set seeds to seeds - item.price
    show link "Home" to "/"

server.start (8080)
```
- A page's lines say **what to show**: `show heading`, `text`, `button`, `picture`, `link ... to ...`, `input ... into name`, and `row`, `column`, `card` that hold other parts. `if` and `each` work too.
- `remember name as value` at the start of the page: when it changes, the page updates by itself. `remember items as server.get ("/api/items")` fills itself from your server.
- **What happens** goes under `when clicked` (buttons), `when typed` (inputs) or `when page opens` (at the start of the page). Inside these you can `set`, `write` (shows a message bar), `server.get`, `server.post`, `go to "/other"`, `if`, `repeat`, `each` and `try`.
- `when clicked` right under a `show box` (or card, row, column) makes the whole box clickable, like a day in a
  calendar. Buttons and inputs inside it still do their own thing.
- Pickers: `show date "Day" into day` (a calendar to pick from, gives text like "2026-11-20"), `show time "Starts" into start`
  (gives "09:30"), and `show file "Choose a file" into words` (reads the chosen file as text; `when chosen` runs after).
- Dragging: `when dragged` under a box lets it be picked up (set a remembered name there to say what's moving);
  `when dropped` under another box runs when it's let go over it.
- Pop-ups: `page.notify ("Title", "more words")` shows a notification on the computer (it asks once for permission).
- On a page, `server.put ("/api/...", value)` and `server.delete ("/api/...")` talk to `Route.Put` and `Route.Delete`.
- Moving between your own pages (`show link`, or `go to`) swaps the new page in without reloading the whole site,
  so it feels like one app, and the browser's back button still works. Links to other sites and to files load normally.
- Pages are served by `server.start`, next to your `Route.`s. `Page.Home ("/")` is the front page.

## Forms and tables
```
Page.Pets ("/pets")
    remember pets as server.get ("/api/pets")
    remember name as ""
    remember kind as ""
    remember age as 0
    remember friendly as on
    remember about as ""
    show input "Name" into name
    show choice "Dog", "Cat", "Sloth" into kind
    show number "Age" into age
    show checkbox "Friendly" into friendly
    show notes "About them" into about
    show button "Add"
        when clicked
            server.post ("/api/pets", lookup "name" is name, "kind" is kind, "age" is age)
            set pets to server.get ("/api/pets")
    show table pets
```
- `show choice "A", "B" into x`: a drop-down list. It starts on the first one. (`show choice options into x` works with a list too.)
- `show number "Age" into age`: a box for numbers; `age` is a number, or nothing when the box is empty.
- `show checkbox "Friendly" into friendly`: a tick box; `friendly` is on or off.
- `show notes "About them" into about`: a big box for many lines.
- `when changed` under a checkbox or choice runs when it changes (`when typed` for number and notes).
- `show table pets`: each Thing (or lookup) in the list is a row, and its parts are the columns. A list of lists works too.
- Long lists stay fast: when one item is added or taken away, only that item changes on the page.

More page parts: `show subheading`, `show box` (holds parts), `show nav` (a menu bar), `show footer`,
`show video "/intro.mp4"`, `show secret "Password" into password` (hides what you type) and
`show html "<canvas id='stars'></canvas>"` (your own HTML, for special effects).

## Screens, charts and maps on pages
```
Page.Home ("/")
    remember screen as "Sales"
    remember sales as lookup "Mon" is 3, "Tue" is 5, "Wed" is 2
    show tabs "Sales", "Map" into screen
    if screen is "Sales"
        show barchart sales
    otherwise
        show map 9.93, -84.08
```
- `show tabs "A", "B" into screen` makes tabs; clicking one sets `screen`. Show each screen with `if`.
- Charts: `show barchart`, `show linechart`, `show piechart` with a lookup or a list of numbers.
- `show map latitude, longitude` (and a zoom from 1 to 18 if you like) shows a map from OpenStreetMap.
- Pages can use your `Let.` commands too, unless the command talks to the server or waits.
  See [`examples/dashboard`](examples/dashboard).

## Styles
```
Style.Price
    color green
    bold

show text "Hi" style Price
```
Style words:

| Word | Example |
|---|---|
| colors | `color green`, `background "#0f1420"` (names or codes in quotes) |
| size and space | `size 20`, `space 14` (inside), `margin 8` (outside), `gap 10` (between parts) |
| width | `width 300`, `width full`, `maxwidth 1100`, `height 200` |
| edges | `corners round` (or square, circle, a number), `border gray` (or none), `shadow` |
| text | `font "Inter"` (any Google font, or sans, serif, mono, rounded), `weight 700`, `bold`, `italic`, `upper`, `line 1.6`, `spacing 1`, `center` |
| layout | `columns 3` (a grid), `row` (side by side), `wrap`, `spread` (push apart), `align center` (start, center, end), `sticky` (stays at the top), `hidden` |
| motion | `animate fade` (or rise, float, pulse, spin), `opacity 0.8` |
| anything else | `css "letter-spacing: 2px; text-decoration: none"` |

Put `hover`, `dark` or `phone` in front of any style line:

```
Style.Track
    background white
    hover border green
    dark background "#16203a"
    phone columns 1
```
A part can use more than one style: `show text "Nap" style Chip, Purple` (later ones win when they clash).

`hover` is when the mouse is on it, `dark` is for people using dark mode, and `phone` is for small screens.

Light and dark: `dark` lines follow the computer's setting. A page can pick instead with `page.theme ("light")`,
`page.theme ("dark")` or `page.theme ("auto")` (follow the computer) inside a `when`, and `page.theme ()` says which
is on. The choice is remembered for next time.
`Style.Page` styles the whole page (background, font) and `Style.Main` the middle column (like `maxwidth 1100`).

## Shared parts (header, footer, cards)
```
Part.Header (who)
    show nav style Nav
        show text "LiteSloth Academy" style Logo
        show link "Home" to "/"
        if who is nothing
            show link "Sign in" to "/signin"
        otherwise
            show text "Hi " + who.name

Page.Home ("/")
    remember me as account.me ()
    Part.Header (me)
    show heading "Welcome"
```
Make a part once with show lines under it, then use it on any page with `Part.Name (...)`. A part gets what it
needs in its ( ); it can't use the page's remembered names directly.

## Your own files (pictures, videos, downloads)
```
server.files ("public")
```
Files in the `public` folder next to your program open at their own address:
`public/charlie.png` is `/charlie.png`, so `show picture "/charlie.png"` works. Folder listings stay hidden.

## Scripts and special effects
```
bring in script "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"
bring in script "/space.js"
bring in stylesheet "/site.css"
```
At the start of the program they go on every page; inside a `Page.` only on that page. Pair them with
`show html "<canvas id='space'></canvas>"` to give a script a place to draw.

## Accounts (sign up, sign in, sign out)
```
bring in database "academy"
bring in accounts

Route.Get ("/api/seeds")
    if request.user is nothing
        give back error 401, "Please sign in"
    give back "Hello " + request.user

Page.SignIn ("/signin")
    remember name as ""
    remember password as ""
    show input "Your name" into name
    show secret "Password" into password
    show button "Sign in"
        when clicked
            try
                account.signin (name, password)
                go to "/"
            otherwise
                write "Wrong name or password"
```
- On pages: `account.signup (name, password)`, `account.signin (name, password)`, `account.signout ()`, and `account.me ()` (the signed-in person, with `.name`, or `nothing`).
- In routes: `request.user` is the signed-in person's name, or `nothing`.
- Passwords need 8 or more characters and are never stored, only a slow scrambled version (PBKDF2). Sign-ins use a private cookie for 30 days, and other websites can't make changes using someone's sign-in.

## Checks before running
`scrawl run` and `scrawl check` (and Space Coder, while you type) look for mistakes before the program starts:
```
Thing.Pet (name, age)
set rex to Thing.Pet ("Rex", 3)
write rex.nmae
```
```
Line 3: a Pet has no part .nmae. Did you mean .name? (Thing.Pet has: age, name)
```
They catch misspelled parts of Things, actions that text, numbers or lists don't have (`5.upper ()`),
math with text or on/off (`"a" - 1`), and comparing a number with text, which is never true (`if n is "5"`).
They only speak up when they're sure; anything else is still checked while the program runs.

## Tests
```
Let.Add (a, b)
    give back a + b

Test.Adding ()
    expect Let.Add (1, 2) is 3
    expect Let.Add (2, 2) is not 5

Test.SavingAPet ()
    set saved to server.post ("/api/pets", lookup "name" is "Rex")
    expect saved.name is "Rex"
    expect server.get ("/api/pets").count () is 1

Test.NeedsAName ()
    expect problem "Give the pet a name"
        server.post ("/api/pets", lookup "name" is "")
```
```
scrawl test pets.scrawl
  ✓ Adding
  ✗ SavingAPet
      line 10: expected 1 but got 2
        10 | expect server.get ("/api/pets").count () is 1
  ✓ NeedsAName
```
- `Test.Name ()` holds `expect` lines. `scrawl test file.scrawl` (or **Run Tests** in Space Coder) runs every test and
  says which passed. `scrawl run` skips tests.
- `expect` takes any check: `expect total is 10`, `expect age is more than 3`, `expect list.has ("Rex")`.
  A failed `expect` shows what it got, and the test keeps going so you see every miss.
- `expect problem` (or `expect problem "words"`) passes only if the lines under it go wrong (with a problem saying those words).
- In a test, `server.get`, `server.post`, `server.put` and `server.delete` ask your own `Route.`s, without starting a server.
- Tests run in order and get a **fresh, empty database** (thrown away afterwards), so your real data is never touched.
  The rest of the program runs first, quietly: `write` lines don't show and `server.start` / `app.start` don't start.
  Files are real, so tests that save files save them for real.
- [`examples/calendar`](examples/calendar) has tests at the end.

## When things go wrong
```
try
    set n to answer.number ()
otherwise
    write "That's not a number"
```
If a problem stops the program, Scrawl shows the line it happened on, and a tip when it knows one:
```
Problem on line 4: can't add nothing, only numbers

    4 | write p + 1

Tip: a name holds nothing until it's set...
```

## Doing slow things at the same time
```
at the same time
    set weather to web.get ("https://...")
    set news to web.get ("https://...")

each page in pages at the same time
    pages.add (web.get (page))
```
Each line (or each item) runs side by side, so the waiting happens together. Scrawl code still
takes turns, so names don't clash. `give back`, `stop` and `skip` can't go directly inside.

### Channels (passing values between jobs)
```
set orders to channel ()

Let.Shop ()
    each item in list "nuts", "leaves", "berries"
        orders.send (item)
    orders.close ()

Let.Cook ()
    each order in orders
        write "cooking " + order

at the same time
    Let.Shop ()
    Let.Cook ()
```
- `channel ()` hands each value straight to a job that takes it; `channel (10)` can hold up to 10 waiting values.
- `orders.send (x)` puts a value in (it waits if there's no room). `orders.take ()` waits for the next value,
  and gives `nothing` once the channel is closed and empty.
- `orders.close ()` says no more values are coming. `each x in orders` takes values until then.
- `orders.count ()` is how many values are waiting; `orders.closed ()` is on once it's closed.
- If every job is waiting on a channel and none can ever go on, Scrawl stops with a clear problem instead of hanging.

## Raw Go and Python
For the rare times Scrawl doesn't have a word for something, write a few lines of Go or Python:
```
set n to 20
set big to 0
raw python:
    import math
    big = math.factorial(n)
write big

set shout to "hello"
raw go:
    import "strings"
    shout = strings.ToUpper(shout.(string)) + "!"
write shout
```
- The Scrawl names the code mentions are handed in, and what the code leaves in them comes back.
  To get an answer out, `set` the name first (like `set big to 0`).
- Lists, things and lookups go to Python as lists and dicts; changes come back.
- In Go, numbers are `float64`, text is `string`, and other values are `any` (use `.(float64)` to get a number out).
  Put `import "..."` lines at the top of the block.
- Raw blocks work in programs, `Let.` and `Route.` commands, not on pages.

## Tidy up
`scrawl tidy file.scrawl` lines everything up: 4 spaces for each block, notes next to their code,
no extra spaces or blank lines. A file with a mistake isn't changed. In Space Coder: right-click, Tidy Up.

## Desktop apps
```
Page.Home ("/")
    show heading "Sloth Clicker"

app.start (900, 650)
```
`app.start` (in place of `server.start`) opens your pages in a window of their own, like a desktop app,
using Chrome, Edge or Brave if the computer has one (otherwise the normal browser). Only this computer can
reach it, and the program ends when the window closes. On a Mac, `scrawl build clicker.scrawl -o "Sloth Clicker.app"`
makes an app you can double-click (a `public` folder next to the program goes inside it).

Programs for other computers: add `--for` to `scrawl build`.
```
scrawl build calendar.scrawl --for windows -o "Pure Calendar"
scrawl build calendar.scrawl --for linux -o pure-calendar
scrawl build calendar.scrawl --for mac-arm -o "Pure Calendar.app"
```
`--for` can be `linux`, `linux-arm`, `windows`, `windows-arm`, `mac` (Intel) or `mac-arm` (Apple M1 and newer).
Windows window apps open without a black console box. Copy the `public` folder next to the program too (a Mac `.app` has it inside).

## Finding bugs step by step
In Space Coder, press **F5** (or pick Debug next to the ▶ Run button). Click left of a line number to put a red dot
(a breakpoint) there, and the program stops when it gets to that line. Then:

- **Step Over** runs the line and stops at the next one. **Step Into** goes inside a `Let.` command. **Step Out** finishes it.
- The **Variables** view shows every name: **Here** (the command's own names) and **Program** (the top-level ones).
  Open a list, thing or lookup to see inside. Hover a name in the code to see its value.
- When a problem happens that no `try` catches, the debugger stops there first, so you can see what the names held.

From the Terminal, `scrawl debug file.scrawl` builds the program ready for a debugger (without one it just runs).

## Coming in later versions
Things' own commands on pages, pictures from your computer on pages, and real native windows.
