// Daris, the LiteSloth AI teammate, in a Space side panel.
// Questions go to Daris on puresearch.io (with the open Scrawl file and its
// underlined mistake, if the learner ticks the box). The Scrawl code in each
// answer is checked here with `scrawl check` before the learner sees it.
'use strict';

const vscode = require('vscode');
const cp = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const core = require('./core');

const VIEW = 'spaceCoder.daris';
const DEFAULT_URL = 'https://puresearch.io/api/space/daris';

class DarisPanel {
  constructor(context, helpers) {
    this.context = context;
    this.helpers = helpers; // { scrawlPath(doc), diagnostics }
    this.view = null;
    this.history = []; // [{role, content}]
    this.busy = false;
    this.lastEditor = null;
    this.pending = null;
  }

  // the last Scrawl file the learner looked at (the panel itself takes focus)
  editor() {
    const ed = vscode.window.activeTextEditor;
    if (ed && ed.document.languageId === 'scrawl') this.lastEditor = ed;
    if (this.lastEditor && this.lastEditor.document.isClosed) this.lastEditor = null;
    return this.lastEditor;
  }

  resolveWebviewView(view) {
    this.view = view;
    view.webview.options = { enableScripts: true, localResourceRoots: [] };
    view.webview.html = this.html(view.webview);
    view.webview.onDidReceiveMessage((m) => this.onMessage(m));
    view.onDidDispose(() => { this.view = null; });
    if (this.pending) {
      const p = this.pending;
      this.pending = null;
      setTimeout(() => this.ask(p.text, p.problem), 300);
    }
  }

  post(m) {
    if (this.view) this.view.webview.postMessage(m);
  }

  async onMessage(m) {
    if (!m || typeof m !== 'object') return;
    if (m.type === 'ask') return this.ask(String(m.text || ''), '');
    if (m.type === 'include') return this.context.globalState.update('spaceCoder.darisIncludeFile', !!m.value);
    if (m.type === 'copy') {
      await vscode.env.clipboard.writeText(String(m.code || ''));
      vscode.window.setStatusBarMessage('$(check) Copied', 2000);
      return;
    }
    if (m.type === 'insert') return this.insert(String(m.code || ''));
    if (m.type === 'new') return this.newChat();
  }

  newChat() {
    this.history = [];
    this.post({ type: 'clear' });
  }

  async insert(code) {
    if (code && !code.endsWith('\n')) code += '\n';
    const ed = this.editor();
    if (!ed) {
      const doc = await vscode.workspace.openTextDocument({ language: 'scrawl', content: code });
      await vscode.window.showTextDocument(doc);
      return;
    }
    await vscode.window.showTextDocument(ed.document, ed.viewColumn);
    await ed.edit((b) => b.replace(ed.selection, code));
  }

  // From the right-click menu or "Ask Daris about this mistake".
  async askFromEditor(arg) {
    const ed = this.editor();
    let text = '';
    let problem = '';
    if (arg && arg.problem) {
      problem = String(arg.problem);
      text = 'scrawl check says: ' + problem + '\nWhat does this mean, and how do I fix it?';
    } else if (ed && !ed.selection.isEmpty) {
      text = 'Can you explain this Scrawl code?\n```scrawl\n' + ed.document.getText(ed.selection) + '\n```';
    }
    await vscode.commands.executeCommand(VIEW + '.focus');
    if (!text) return;
    if (!this.view) {
      this.pending = { text, problem };
      return;
    }
    this.ask(text, problem);
  }

  includeFile() {
    return this.context.globalState.get('spaceCoder.darisIncludeFile', true);
  }

  async ask(text, problem) {
    text = text.trim().slice(0, 4000);
    if (!text || this.busy) return;
    this.busy = true;
    this.post({ type: 'user', html: core.renderReply(text) });
    this.post({ type: 'busy', value: true });
    try {
      const ed = this.editor();
      const body = { message: text, messages: this.history.slice(-4) };
      if (ed && this.includeFile()) {
        body.code = ed.document.getText().slice(0, 40000);
        body.file = path.basename(ed.document.uri.fsPath || 'program.scrawl');
        body.problem = problem || core.problemText(this.helpers.diagnostics.get(ed.document.uri));
      }
      let reply = await this.send(body);
      let answer = String(reply.answer || '').trim();
      // Check Daris's code with the real scrawl program; one retry if it has a mistake.
      let mistakes = reply.offline ? [] : await this.checkCode(answer, ed && ed.document);
      if (mistakes.length) {
        const retry = await this.send({
          ...body,
          messages: [...body.messages, { role: 'user', content: text }, { role: 'assistant', content: answer }],
          message: 'scrawl check found a mistake in your code: ' + mistakes[0] +
            '\nPlease give the whole answer again with that fixed. Use only Scrawl words from the guide.',
        }).catch(() => null);
        const again = retry && !retry.offline ? String(retry.answer || '').trim() : '';
        if (again) {
          const left = await this.checkCode(again, ed && ed.document);
          if (left.length <= mistakes.length) {
            answer = again;
            reply = retry;
            mistakes = left;
          }
        }
      }
      let shown = answer;
      if (mistakes.length) {
        shown += '\n\n**Heads up:** `scrawl check` still finds a mistake in this code (' + mistakes[0] +
          '). Try it, and ask me again with the mistake if it doesn\'t work.';
      }
      this.history.push({ role: 'user', content: text }, { role: 'assistant', content: answer });
      this.history = this.history.slice(-8);
      this.post({
        type: 'daris',
        html: core.renderReply(shown),
        sources: (reply.sources || []).filter((s) => s && /^https:\/\//.test(String(s.url))).slice(0, 3)
          .map((s) => ({ title: String(s.title || 'Scrawl Guide'), url: String(s.url) })),
        offline: !!reply.offline,
      });
    } catch (e) {
      this.post({ type: 'error', text: e && e.message ? e.message : String(e) });
    } finally {
      this.busy = false;
      this.post({ type: 'busy', value: false });
    }
  }

  async send(body) {
    const url = vscode.workspace.getConfiguration('spaceCoder').get('darisUrl') || DEFAULT_URL;
    if (!/^https:\/\//.test(url) && !/^http:\/\/(localhost|127\.0\.0\.1)[:/]/.test(url)) {
      throw new Error('The Daris address in Settings (spaceCoder.darisUrl) must start with https://');
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 120000);
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
    } catch (e) {
      throw new Error(controller.signal.aborted
        ? 'Daris took too long to answer. Try again in a moment.'
        : 'Space couldn\'t reach Daris. Check your internet connection and try again.');
    } finally {
      clearTimeout(timer);
    }
    let data = {};
    try {
      data = await res.json();
    } catch (e) {
      data = {};
    }
    if (!res.ok) throw new Error(data.detail || 'Daris couldn\'t answer just now (' + res.status + '). Try again in a moment.');
    return data;
  }

  // Runs `scrawl check` on each ```scrawl block. Returns the mistakes found.
  async checkCode(answer, doc) {
    const blocks = core.scrawlBlocks(answer);
    if (!blocks.length) return [];
    const scrawl = this.helpers.scrawlPath(doc);
    if (!scrawl) return [];
    const found = [];
    for (const code of blocks) {
      // a block that brings in other files can't be checked on its own
      if (/^\s*bring\s+in\s+"/m.test(code)) continue;
      const tmp = path.join(os.tmpdir(), 'space-daris-' + process.pid + '-' + crypto.randomBytes(4).toString('hex') + '.scrawl');
      fs.writeFileSync(tmp, code);
      const out = await new Promise((resolve) => {
        cp.execFile(scrawl, ['check', '--json', tmp], { timeout: 15000 }, (err, stdout) => resolve(err && !stdout ? '' : stdout));
      });
      fs.rm(tmp, () => {});
      if (!out) continue;
      const r = core.parseCheck(out, tmp, tmp);
      if (!r.ok) found.push('line ' + r.line + ': ' + r.message);
    }
    return found;
  }

  html(webview) {
    const nonce = crypto.randomBytes(16).toString('base64');
    const checked = this.includeFile() ? ' checked' : '';
    return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { padding: 0 8px 8px; color: var(--vscode-foreground); font-family: var(--vscode-font-family); font-size: var(--vscode-font-size); }
  #log { display: flex; flex-direction: column; gap: 10px; padding: 8px 0 120px; }
  .msg { line-height: 1.45; overflow-wrap: anywhere; }
  .msg p { margin: 0 0 6px; }
  .who { font-weight: 600; font-size: 0.85em; opacity: 0.75; margin-bottom: 2px; }
  .user { background: var(--vscode-input-background); border-radius: 6px; padding: 6px 8px; }
  .error { color: var(--vscode-errorForeground); }
  code { font-family: var(--vscode-editor-font-family); background: var(--vscode-textCodeBlock-background); padding: 0 3px; border-radius: 3px; }
  .code { margin: 6px 0; border: 1px solid var(--vscode-panel-border); border-radius: 6px; overflow: hidden; }
  .code pre { margin: 0; padding: 8px; overflow-x: auto; background: var(--vscode-textCodeBlock-background); }
  .code pre code { padding: 0; background: none; }
  .tools { display: flex; gap: 6px; padding: 4px 6px; justify-content: flex-end; }
  button { background: var(--vscode-button-secondaryBackground); color: var(--vscode-button-secondaryForeground); border: none; border-radius: 4px; padding: 3px 9px; cursor: pointer; font: inherit; }
  button:hover { background: var(--vscode-button-secondaryHoverBackground); }
  #send { background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
  #send:hover { background: var(--vscode-button-hoverBackground); }
  .sources { font-size: 0.85em; opacity: 0.85; }
  a { color: var(--vscode-textLink-foreground); }
  #ask { position: fixed; left: 0; right: 0; bottom: 0; padding: 8px; background: var(--vscode-sideBar-background); border-top: 1px solid var(--vscode-panel-border); }
  textarea { width: 100%; box-sizing: border-box; resize: vertical; min-height: 48px; font: inherit; color: var(--vscode-input-foreground); background: var(--vscode-input-background); border: 1px solid var(--vscode-input-border, transparent); border-radius: 4px; padding: 6px; }
  textarea:focus { outline: 1px solid var(--vscode-focusBorder); }
  .row { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-top: 6px; font-size: 0.9em; }
  .hello { opacity: 0.85; line-height: 1.45; }
  #thinking { display: none; opacity: 0.75; font-style: italic; }
</style></head>
<body>
<div id="log"><div class="hello"><p><strong>Hi, I'm Daris!</strong> Ask me anything about Scrawl: how to do something, what a mistake means, or to explain some code.</p>
<p>Tip: click the lightbulb on an underlined mistake, or select some code and right-click, then choose <em>Ask Daris</em>.</p></div></div>
<div id="thinking">Daris is thinking…</div>
<div id="ask">
  <textarea id="text" placeholder="Ask Daris about Scrawl…" aria-label="Your question"></textarea>
  <div class="row">
    <label title="Your open Scrawl file and its underlined mistake are sent with your question"><input type="checkbox" id="include"${checked}> Include my open Scrawl file</label>
    <span><button id="new" title="Start over">New chat</button> <button id="send">Ask</button></span>
  </div>
</div>
<script nonce="${nonce}">
  const vscode = acquireVsCodeApi();
  const log = document.getElementById('log');
  const text = document.getElementById('text');
  const send = document.getElementById('send');
  const thinking = document.getElementById('thinking');
  function add(cls, who, html) {
    const d = document.createElement('div');
    d.className = 'msg ' + cls;
    const w = document.createElement('div');
    w.className = 'who';
    w.textContent = who;
    const b = document.createElement('div');
    b.innerHTML = html; // made safe by Space Coder (everything escaped)
    d.append(w, b);
    log.appendChild(d);
    d.scrollIntoView({ block: 'end' });
    return d;
  }
  function ask() {
    const t = text.value.trim();
    if (!t || send.disabled) return;
    vscode.postMessage({ type: 'ask', text: t });
    text.value = '';
  }
  send.addEventListener('click', ask);
  text.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(); } });
  document.getElementById('include').addEventListener('change', (e) => vscode.postMessage({ type: 'include', value: e.target.checked }));
  document.getElementById('new').addEventListener('click', () => vscode.postMessage({ type: 'new' }));
  log.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const code = btn.closest('.code').querySelector('pre code').textContent;
    vscode.postMessage({ type: btn.dataset.act, code });
  });
  window.addEventListener('message', (e) => {
    const m = e.data || {};
    if (m.type === 'user') add('user', 'You', m.html);
    else if (m.type === 'daris') {
      const d = add('daris', m.offline ? 'Daris (from the Scrawl Guide)' : 'Daris', m.html);
      if (m.sources && m.sources.length) {
        const s = document.createElement('div');
        s.className = 'sources';
        s.append('Scrawl Guide: ');
        m.sources.forEach((src, i) => {
          if (i) s.append(' · ');
          const a = document.createElement('a');
          a.href = src.url;
          a.textContent = src.title;
          s.append(a);
        });
        d.appendChild(s);
      }
    } else if (m.type === 'error') {
      const d = add('error', 'Daris', '');
      d.lastChild.textContent = m.text;
    } else if (m.type === 'busy') {
      send.disabled = m.value;
      thinking.style.display = m.value ? 'block' : 'none';
      if (m.value) thinking.scrollIntoView({ block: 'end' });
    } else if (m.type === 'clear') {
      while (log.children.length > 1) log.removeChild(log.lastChild);
    }
  });
</script>
</body></html>`;
  }
}

// "Ask Daris about this mistake" on Space Coder's underlines.
const codeActions = {
  provideCodeActions(doc, range, context) {
    const d = (context.diagnostics || []).find((x) => x.source === 'Space Coder');
    if (!d) return [];
    const a = new vscode.CodeAction('Ask Daris about this mistake', vscode.CodeActionKind.QuickFix);
    a.command = {
      command: 'spaceCoder.askDaris',
      title: 'Ask Daris about this mistake',
      arguments: [{ problem: core.problemText([d]) }],
    };
    a.diagnostics = [d];
    return [a];
  },
};

function register(context, helpers) {
  const panel = new DarisPanel(context, helpers);
  return [
    vscode.window.registerWebviewViewProvider(VIEW, panel, { webviewOptions: { retainContextWhenHidden: true } }),
    vscode.commands.registerCommand('spaceCoder.askDaris', (arg) => panel.askFromEditor(arg)),
    vscode.commands.registerCommand('spaceCoder.darisNewChat', () => panel.newChat()),
    vscode.languages.registerCodeActionsProvider('scrawl', codeActions, { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }),
    vscode.window.onDidChangeActiveTextEditor(() => panel.editor()),
  ];
}

module.exports = { register, DarisPanel, codeActions, DEFAULT_URL };
