# LiteSloth Space Coder

The editor add-on for **LiteSloth Scrawl**, the simple programming language from LiteSloth.

- **Colors** for `.scrawl` files (and the **LiteSloth Space** color theme)
- **▶ Run** button at the top right (or press Cmd+Enter / Ctrl+Enter) runs your program in the terminal
- **Debug**: press F5 (or pick Debug next to the Run button). Click left of a line number to put a red dot (a breakpoint) there; the program stops on it. Then step one line at a time, step into or out of commands, and see every name's value in the Variables view (open lists and things to see inside). It also stops on a problem, so you can see what the names held
- **Mistakes underlined in red** as you type, with Scrawl's friendly messages ("Did you mean seeds?")
- **Hover** over a Scrawl word to see what it does
- **Typing shortcuts**: type `if`, `repeat`, `each`, `Let`, `try`, `get`, `post`, `find`... and press Tab
- Right-click for **Run Tests** (runs the `Test.` commands with `scrawl test`), **Build a Program File**, **Show the Go Code** and **Tidy Up** (lines your code up neatly; also Shift+Alt+T)

## Setup

Space Coder needs the `scrawl` program. Release zips have a ready-made one in `bin/`;
copy the one for your computer to `scrawl` in the litesloth-scrawl folder (or build it
with `go build -o scrawl ./cmd/scrawl`).

Space Coder looks for it in your Downloads/litesloth-scrawl folder, your home folder,
your open folder, and on your PATH. If it can't find it, run **Space Coder: Find the
scrawl Program** from the Command Palette (Cmd+Shift+P) and pick the file.

To use the LiteSloth Space colors: Cmd+K then Cmd+T, and pick **LiteSloth Space**.
