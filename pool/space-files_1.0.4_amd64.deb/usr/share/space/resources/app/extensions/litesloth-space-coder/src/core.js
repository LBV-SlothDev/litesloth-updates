// Logic for LiteSloth Space Coder that doesn't need VS Code (so it can be tested).
'use strict';

const path = require('path');

// Places to look for the scrawl program, in order.
function scrawlCandidates({ configured, home, platform, workspaceFolders = [], fileDir }) {
  const exe = platform === 'win32' ? 'scrawl.exe' : 'scrawl';
  const list = [];
  if (configured) list.push(configured);
  for (const w of workspaceFolders) list.push(path.join(w, exe));
  if (fileDir) {
    let d = fileDir;
    for (let i = 0; i < 4; i++) {
      list.push(path.join(d, exe));
      const up = path.dirname(d);
      if (up === d) break;
      d = up;
    }
  }
  if (home) {
    for (const where of ['Downloads/litesloth-scrawl', 'litesloth-scrawl', 'projects/litesloth-scrawl', 'Documents/litesloth-scrawl', 'Desktop/litesloth-scrawl', 'go/bin']) {
      list.push(path.join(home, where, exe));
    }
  }
  if (platform !== 'win32') list.push('/usr/local/bin/scrawl', '/opt/homebrew/bin/scrawl');
  return [...new Set(list)];
}

// Finds the scrawl program. isFile(p) says whether a file exists there;
// onPath(name) gives the full path if the name is on the PATH.
function findScrawl(opts, isFile, onPath) {
  if (opts.configured) return isFile(opts.configured) ? opts.configured : null;
  for (const p of scrawlCandidates(opts)) {
    if (isFile(p)) return p;
  }
  return onPath ? onPath(opts.platform === 'win32' ? 'scrawl.exe' : 'scrawl') : null;
}

// Reads the output of `scrawl check --json`. checkedPath is the file that was
// checked; realPath is the file the person is editing (they differ while typing).
function parseCheck(stdout, checkedPath, realPath) {
  let r;
  try {
    r = JSON.parse(String(stdout).trim().split('\n').pop());
  } catch (e) {
    return { ok: false, file: realPath, line: 1, message: 'Space Coder could not read the answer from scrawl: ' + String(stdout).slice(0, 200) };
  }
  if (r.ok) return { ok: true };
  const line = Math.max(1, Number(r.line) || 1);
  let file = realPath;
  if (r.file && r.file !== path.basename(checkedPath)) {
    // a mistake in a brought-in file: its name is relative to the checked file
    file = path.join(path.dirname(realPath), r.file);
  }
  return { ok: false, file, line, message: r.message || 'Something is wrong here' };
}

// Quotes a path for the terminal the Run button types into.
function quoteForShell(p, platform) {
  if (platform === 'win32') return '"' + p.replace(/"/g, '""') + '"';
  return "'" + p.replace(/'/g, "'\\''") + "'";
}

function runCommand(scrawl, verb, file, platform) {
  const q = (p) => quoteForShell(p, platform);
  const cmd = q(scrawl) + ' ' + verb + ' ' + q(file);
  return platform === 'win32' ? '& ' + cmd : cmd;
}

// Short explanations shown when the mouse rests on a word.
const WORDS = {
  write: ['write "Hello"', 'Shows something on the screen.'],
  set: ['set seeds to 10', 'Stores a value under a name. Use it again to change the value.'],
  ask: ['set name to ask "Your name? "', 'Asks the person a question and gives back what they typed (as text).'],
  if: ['if seeds is more than 12', 'Runs the indented lines under it only when the check is true.'],
  otherwise: ['otherwise', 'What to do when the if above it (or a try) does not work out. `otherwise if` adds another check.'],
  repeat: ['repeat 4 times / repeat until ... / repeat forever', 'Runs the indented lines again and again.'],
  each: ['each fruit in fruits', 'Goes through a list (or the letters of some text), one at a time.'],
  stop: ['stop', 'Leaves the loop it is in.'],
  skip: ['skip', 'Jumps to the next round of the loop.'],
  try: ['try ... otherwise', 'Tries the indented lines. If something goes wrong, runs the lines under otherwise instead of stopping.'],
  give: ['give back total', 'Hands an answer back from a Let. or Route. command. In a Route: `give back error 404, "Not found"`.'],
  list: ['set fruits to list "apple", "kiwi"', 'Makes a list. Lists can .add, .remove, .count, .has, .sort, .first, .last, .item (2), .join (", ").'],
  on: ['on', 'Yes / true.'],
  off: ['off', 'No / false.'],
  nothing: ['nothing', 'No value. For example `if learner is nothing`.'],
  is: ['is, is not, is more than, is less than, is at least, is at most', 'Compares two values.'],
  bring: ['bring in "file.scrawl" / bring in pandas / bring in database "name" [as sqlite]', 'Uses another Scrawl file, a Python library, or a database. Add `as sqlite` to keep it in SQLite (run `scrawl setup sqlite` once first).'],
  note: ['note: ...', 'A note for people. Scrawl skips it.'],
  Let: ['Let.Greet (person)', 'Makes your own command (with indented lines under it), or uses one (without).'],
  Thing: ['Thing.Player (name, score)', 'Makes a kind of thing with parts. `Thing.Player ("Charlie", 10)` makes one; `p.score` reads a part.'],
  Route: ['Route.Get ("/api/learners/{name}")', 'A web address your server answers. Also Route.Post, Route.Put, Route.Delete.'],
  request: ['request.amount', 'Inside a Route: what was sent (from the address, the JSON body, or ?amount= in the link).'],
  server: ['server.start (8080)', 'Starts your web server on a port.'],
  db: ['db.save / db.delete / db.find / db.first / db.count / db.sql', 'The database from `bring in database "name"`. With `as sqlite`, `db.sql ("select ...", values)` asks with plain SQL and gives back a list of lookups.'],
  sqlite: ['bring in database "shop" as sqlite', 'Keeps the database in shop.sqlite. Run `scrawl setup sqlite` once first. An older shop.scrawldb.json moves in by itself.'],
  file: ['file.save ("notes.txt", text) / file.open ("notes.txt")', 'Saves and opens text files.'],
  web: ['web.get (url) / web.post (url, value)', 'Talks to other websites. JSON answers become lists and things.'],
  and: ['and', 'Both checks must be true.'],
  or: ['or', 'At least one check must be true.'],
  not: ['not', 'Flips on to off and off to on.'],
  plus: ['plus', 'Adds, like +.'],
  minus: ['minus', 'Subtracts, like -.'],
  times: ['times', 'Multiplies, like *. Also used in `repeat 4 times`.'],
  divided: ['divided by', 'Divides, like /.'],
  Page: ['Page.Shop ("/shop")', 'A web page. Its lines say what to show; when ... lines say what happens.'],
  Style: ['Style.Card', 'A look you can reuse: lines like color green, background white, corners round, space 14, size 20, bold, center, shadow. Use it with: show card style Card.'],
  show: ['show heading / text / button / picture / link / input / row / column / card', 'Puts a part on the page.'],
  remember: ['remember seeds as 120', 'A value the page remembers. When it changes, the page updates by itself.'],
  when: ['when clicked / when typed / when changed / when page opens', 'What happens when a button is clicked, a box is typed in, a checkbox or choice changes, or the page opens.'],
  go: ['go to "/shop"', 'Moves to another page.'],
  into: ['show input "Your name" into name', 'What you type goes into this remembered name.'],
  Part: ['Part.Header (who)', 'A piece of page many pages share, like a menu or footer. Make it once with show lines under it; use it in a page with Part.Header (me).'],
  secret: ['show secret "Password" into password', 'A box that hides what you type.'],
  account: ['account.signup / signin (name, password), account.signout (), account.me ()', 'Sign up, sign in and out on a page. Needs bring in accounts.'],
  html: ['show html "<canvas id=\'stars\'></canvas>"', 'Puts your own HTML on the page (for special effects with bring in script).'],
  files: ['server.files ("public")', 'Shares a folder: public/charlie.png opens at /charlie.png.'],
  lookup: ['set prices to lookup "apple" is 2, "kiwi" is 3', 'Names that point to values. Lookups can .item ("apple"), .set ("mango", 5), .has, .remove, .count, .keys, .values.'],
  random: ['random.number (1, 6) / random.pick (fruits)', 'A whole number by chance, or one item picked by chance.'],
  time: ['time.now () / time.today () / time.date ("2026-12-25") / time.wait (2)', 'Dates and times. A date can .add (3, "days"), .until (other, "days"), .ago (), .weekday (), .date (), .clock (), .text ("monthname day, year").'],
  shuffle: ['cards.shuffle ()', 'Mixes a list into a random order.'],
  total: ['scores.total ()', 'Adds up every number in a list.'],
  average: ['scores.average ()', 'The average of the numbers in a list.'],
  biggest: ['scores.biggest ()', 'The biggest number in a list. Also .smallest ().'],
  smallest: ['scores.smallest ()', 'The smallest number in a list. Also .biggest ().'],
  commas: ['seeds.commas () / price.commas (2)', 'Shows a number with commas: 1,234,567 or 1,234.50.'],
  roundup: ['price.roundup ()', 'Rounds up to a whole number (2.1 becomes 3). Also .rounddown ().'],
  rounddown: ['price.rounddown ()', 'Rounds down to a whole number (2.9 becomes 2). Also .roundup ().'],
  capital: ['name.capital ()', 'Makes the first letter big: charlie becomes Charlie.'],
  until: ['today.until (christmas, "days")', 'How many whole days (or seconds, minutes, hours, weeks, months, years) until another date.'],
  ago: ['posted.ago ()', 'Says how long ago a date was: 3 days ago, in 2 hours, just now.'],
  raw: ['raw python: / raw go:', 'A few lines of Python or Go, indented under it. The Scrawl names the code mentions go in, and what it leaves in them comes back.'],
  app: ['app.start (900, 650)', 'Opens your pages in a window of their own, like a desktop app (put it at the end, in place of server.start). The program ends when the window closes. On a Mac, scrawl build file.scrawl -o Name.app makes an app you can double-click.'],
  folder: ['folder.list ("photos") / folder.make / folder.exists / folder.delete / folder.here ()', 'Works with folders. folder.delete only deletes empty folders.'],
  channel: ['set orders to channel () / channel (10)', 'Passes values between jobs running at the same time. `orders.send (x)` puts one in, `orders.take ()` waits for the next one, `orders.close ()` says no more are coming, and `each x in orders` takes them until it is closed.'],
  send: ['orders.send (value)', 'Puts a value into a channel. Waits if the channel is full.'],
  take: ['orders.take ()', 'Takes the next value from a channel, waiting until there is one. Gives nothing once the channel is closed and empty.'],
  notify: ['page.notify ("Title", "more words")', 'Shows a pop-up notification on the computer, from a page.'],
  dragged: ['when dragged / when dropped', 'Under a show box: dragged lets it be picked up, dropped runs when something is let go over it.'],
  kind: ['rex.kind ()', 'The name of the Thing a thing was made from, like "Dog".'],
  same: ['at the same time', 'The lines under it run side by side, so slow jobs (web.get, time.wait) wait together. Also: each url in urls at the same time.'],
  my: ['my.age', 'Inside a thing\'s own command (Let.Pet.Birthday ()), my is the thing itself.'],
  tabs: ['show tabs "Home", "Shop" into screen', 'A row of tabs. Clicking one sets screen; show each screen with if screen is "Shop".'],
  barchart: ['show barchart sales', 'A bar chart of a lookup (lookup "Mon" is 3, "Tue" is 5) or a list of numbers. Also linechart and piechart.'],
  linechart: ['show linechart sales', 'A line chart of a lookup or a list of numbers.'],
  piechart: ['show piechart snacks', 'A pie chart of a lookup or a list of numbers.'],
  map: ['show map 39.74, -104.99', 'A map at that spot (and a zoom from 1 to 18 if you like: show map 39.74, -104.99, 15).'],
  Test: ['Test.Adding ()', 'A test: expect lines under it say what should be true. Run every test with scrawl test file.scrawl (or Space Coder: Run Tests). Tests use a fresh, empty database, so your real data is safe.'],
  expect: ['expect Let.Add (1, 2) is 3', 'Inside a Test.: says what should be true. If it is not, the test fails and shows what it got. expect problem "words" (with lines under it) passes only when those lines go wrong.'],
  problem: ['expect problem "Give the event a name"', 'Inside a Test.: the lines under it should go wrong, with a problem that says those words.'],
  checkbox: ['show checkbox "Done" into done', 'A tick box. done is on or off (remember done as off). Put when changed under it to do something when it is ticked.'],
  notes: ['show notes "Notes" into notes', 'A big box for typing many lines.'],
  number: ['show number "How many" into amount', 'A box for typing a number; amount is a number (or nothing when the box is empty).'],
  choice: ['show choice "Blue", "Red", "Green" into color', 'A drop-down list to pick one from. It starts on the first one. Put when changed under it to do something when a new one is picked.'],
  table: ['show table pets', 'A table: each Thing (or lookup) in the list is a row, and its parts are the columns.'],
  changed: ['when changed', 'Under show checkbox or show choice: runs when it is ticked or a new one is picked.'],
  hover: ['hover background green', 'In a Style: how it looks when the mouse is on it. Also dark (dark mode) and phone (small screens).'],
};

function hoverFor(word) {
  const w = WORDS[word];
  if (!w) return null;
  return '**' + word + '**: ' + w[1] + '\n\n```scrawl\n' + w[0] + '\n```';
}

module.exports = { scrawlCandidates, findScrawl, parseCheck, quoteForShell, runCommand, hoverFor, WORDS };
