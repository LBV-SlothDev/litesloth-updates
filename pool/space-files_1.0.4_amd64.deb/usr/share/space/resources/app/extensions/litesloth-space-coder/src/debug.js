// LiteSloth Space Coder: the step-through debugger for Scrawl.
//
// This speaks VS Code's Debug Adapter Protocol on one side and Scrawl's small
// debug protocol on the other. It runs `scrawl debug file.scrawl` in the
// terminal with SCRAWL_DEBUG=127.0.0.1:<port>; the program connects back and
// sends {"event":"stopped",...} lines; we send {"cmd":"continue"} and so on.
// It doesn't need the vscode module, so it can be tested on its own.
'use strict';

const net = require('net');
const path = require('path');
const cp = require('child_process');

function samePath(a, b) {
  const norm = (p) => path.resolve(p).replace(/\\/g, '/');
  const x = norm(a), y = norm(b);
  return process.platform === 'linux' ? x === y : x.toLowerCase() === y.toLowerCase();
}

class ScrawlDebugSession {
  constructor() {
    this.seq = 1;
    this.listeners = [];
    this.breakpoints = new Map(); // file path -> [lines]
    this.files = []; // the program's files (from its hello)
    this.frames = [];
    this.handles = new Map();
    this.nextHandle = 1;
    this.configured = false;
    this.started = false;
    this.ended = false;
    this.firstStop = false;
    this.pending = new Map(); // our requests to VS Code, by seq
    // VS Code's Event shape: onDidSendMessage(listener) -> { dispose }
    this.onDidSendMessage = (listener, thisArg) => {
      const fn = thisArg ? listener.bind(thisArg) : listener;
      this.listeners.push(fn);
      return { dispose: () => { this.listeners = this.listeners.filter((l) => l !== fn); } };
    };
  }

  // ---------- sending to VS Code ----------
  send(msg) {
    msg.seq = this.seq++;
    for (const l of this.listeners.slice()) l(msg);
  }
  respond(req, body, error) {
    const msg = { type: 'response', request_seq: req.seq, command: req.command, success: !error, body: body || {} };
    if (error) msg.message = error;
    this.send(msg);
  }
  event(name, body) { this.send({ type: 'event', event: name, body: body || {} }); }
  output(text, category) { this.event('output', { category: category || 'console', output: text }); }
  request(command, args) {
    return new Promise((resolve) => {
      const seq = this.seq;
      this.pending.set(seq, resolve);
      this.send({ type: 'request', command, arguments: args });
    });
  }

  // ---------- sending to the program ----------
  tell(cmd) {
    if (this.sock && !this.sock.destroyed) this.sock.write(JSON.stringify(cmd) + '\n');
  }
  sendBreakpoints() {
    for (const [file, lines] of this.breakpoints) {
      const theirs = this.files.find((f) => samePath(f, file)) || file;
      this.tell({ cmd: 'breakpoints', file: theirs, lines });
    }
  }
  startIfReady() {
    if (this.started || !this.configured || !this.sock) return;
    this.started = true;
    this.sendBreakpoints();
    this.tell({ cmd: this.stopOnEntry ? 'in' : 'continue' });
  }

  // ---------- messages from VS Code ----------
  handleMessage(msg) {
    if (msg.type === 'response') {
      const done = this.pending.get(msg.request_seq);
      if (done) { this.pending.delete(msg.request_seq); done(msg); }
      return;
    }
    if (msg.type !== 'request') return;
    const a = msg.arguments || {};
    try {
      switch (msg.command) {
        case 'initialize':
          this.canTerminal = !!a.supportsRunInTerminalRequest;
          this.respond(msg, {
            supportsConfigurationDoneRequest: true,
            supportsTerminateRequest: true,
            supportsSingleThreadExecutionRequests: false,
          });
          this.event('initialized');
          break;
        case 'launch':
          this.launch(msg, a);
          break;
        case 'setBreakpoints': {
          const file = (a.source && a.source.path) || '';
          const lines = (a.breakpoints || a.lines || []).map((b) => (typeof b === 'number' ? b : b.line));
          this.breakpoints.set(file, lines);
          if (this.started) {
            const theirs = this.files.find((f) => samePath(f, file)) || file;
            this.tell({ cmd: 'breakpoints', file: theirs, lines });
          }
          this.respond(msg, { breakpoints: lines.map((line) => ({ verified: true, line })) });
          break;
        }
        case 'setExceptionBreakpoints':
          this.respond(msg, {});
          break;
        case 'configurationDone':
          this.configured = true;
          this.respond(msg);
          this.startIfReady();
          break;
        case 'threads':
          this.respond(msg, { threads: [{ id: 1, name: 'Scrawl' }] });
          break;
        case 'stackTrace':
          this.respond(msg, {
            stackFrames: this.frames.map((f, i) => ({
              id: i + 1,
              name: f.name,
              line: f.line || 1,
              column: 1,
              source: f.file ? { name: path.basename(f.file), path: f.file } : undefined,
            })),
            totalFrames: this.frames.length,
          });
          break;
        case 'scopes': {
          const f = this.frames[(a.frameId || 1) - 1];
          const scopes = (f ? f.scopes : []).map((s) => ({
            name: s.name,
            variablesReference: this.handle(s.vars || []),
            expensive: false,
          }));
          this.respond(msg, { scopes });
          break;
        }
        case 'variables': {
          const vars = this.handles.get(a.variablesReference) || [];
          this.respond(msg, {
            variables: vars.map((v) => ({
              name: v.name,
              value: v.value,
              type: v.kind,
              variablesReference: v.kids && v.kids.length ? this.handle(v.kids) : 0,
            })),
          });
          break;
        }
        case 'continue':
          this.resume('continue');
          this.respond(msg, { allThreadsContinued: true });
          break;
        case 'next':
          this.resume('next');
          this.respond(msg);
          break;
        case 'stepIn':
          this.resume('in');
          this.respond(msg);
          break;
        case 'stepOut':
          this.resume('out');
          this.respond(msg);
          break;
        case 'pause':
          this.tell({ cmd: 'pause' });
          this.respond(msg);
          break;
        case 'evaluate': {
          // hovering a name, or typing one in the Debug Console
          const name = String(a.expression || '').trim();
          const top = this.frames[(a.frameId || 1) - 1] || this.frames[0];
          let found;
          for (const s of top ? top.scopes : []) {
            found = (s.vars || []).find((v) => v.name.toLowerCase() === name.toLowerCase());
            if (found) break;
          }
          if (!found) {
            this.respond(msg, null, a.context === 'hover' ? 'not a name' : 'Only names can be looked at here, like: score');
            break;
          }
          this.respond(msg, {
            result: found.value,
            type: found.kind,
            variablesReference: found.kids && found.kids.length ? this.handle(found.kids) : 0,
          });
          break;
        }
        case 'terminate':
        case 'disconnect':
          this.tell({ cmd: 'quit' });
          if (this.child) this.child.kill();
          this.respond(msg);
          this.finish();
          break;
        default:
          this.respond(msg, null, 'Space Coder\'s debugger can\'t do ' + msg.command + ' yet');
      }
    } catch (err) {
      this.respond(msg, null, String(err && err.message ? err.message : err));
    }
  }

  handle(list) {
    const h = this.nextHandle++;
    this.handles.set(h, list);
    return h;
  }

  resume(cmd) {
    this.frames = [];
    this.handles.clear();
    this.tell({ cmd });
  }

  launch(req, a) {
    if (!a.program) return this.respond(req, null, 'Which .scrawl file? Open one and press F5.');
    if (!a.scrawlPath) return this.respond(req, null, 'Space Coder can\'t find the scrawl program. Use "Space Coder: Find the scrawl Program" first.');
    this.stopOnEntry = !!a.stopOnEntry;
    const server = net.createServer((sock) => {
      if (this.sock) return sock.destroy(); // only the first program
      this.sock = sock;
      server.close();
      let buf = '';
      sock.setEncoding('utf8');
      sock.on('data', (d) => {
        buf += d;
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i);
          buf = buf.slice(i + 1);
          if (line.trim()) this.fromProgram(JSON.parse(line));
        }
      });
      sock.on('close', () => this.finish());
      sock.on('error', () => this.finish());
    });
    this.server = server;
    server.listen(0, '127.0.0.1', () => {
      const addr = '127.0.0.1:' + server.address().port;
      const cwd = path.dirname(a.program);
      const args = [a.scrawlPath, 'debug', a.program];
      if (this.canTerminal && !a.noTerminal) {
        // in the terminal, so `ask` can be answered
        this.request('runInTerminal', { kind: 'integrated', title: 'Scrawl debug', cwd, args, env: { SCRAWL_DEBUG: addr } }).then((r) => {
          if (!r.success) this.output('Couldn\'t open a terminal: ' + (r.message || '') + '\n', 'stderr');
        });
      } else {
        const child = cp.spawn(args[0], args.slice(1), { cwd, env: Object.assign({}, process.env, { SCRAWL_DEBUG: addr }) });
        this.child = child;
        child.stdout.on('data', (d) => this.output(String(d), 'stdout'));
        child.stderr.on('data', (d) => this.output(String(d), 'stderr'));
        child.on('error', (err) => { this.output('Couldn\'t start scrawl: ' + err.message + '\n', 'stderr'); this.finish(); });
        child.on('exit', () => { if (!this.sock) this.finish(); });
      }
      this.respond(req);
    });
  }

  fromProgram(m) {
    if (m.event === 'hello') {
      this.files = m.files || [];
      this.startIfReady();
    } else if (m.event === 'stopped') {
      this.frames = m.frames || [];
      this.handles.clear();
      let reason = m.reason;
      if (!this.firstStop && this.stopOnEntry && reason === 'step') reason = 'entry';
      this.firstStop = true;
      const body = { reason, threadId: 1, allThreadsStopped: true };
      if (m.message) {
        body.description = 'Problem';
        body.text = m.message;
        this.output(m.message + '\n', 'stderr');
      }
      this.event('stopped', body);
    }
  }

  finish() {
    if (this.ended) return;
    this.ended = true;
    if (this.server) try { this.server.close(); } catch (e) { /* already closed */ }
    this.event('terminated');
  }

  dispose() {
    if (this.sock) this.sock.destroy();
    if (this.child) this.child.kill();
    if (this.server) try { this.server.close(); } catch (e) { /* already closed */ }
  }
}

module.exports = { ScrawlDebugSession, samePath };
