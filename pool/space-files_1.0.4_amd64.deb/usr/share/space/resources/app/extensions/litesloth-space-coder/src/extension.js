// LiteSloth Space Coder: the editor add-on for LiteSloth Scrawl.
'use strict';

const vscode = require('vscode');
const cp = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const core = require('./core');
const { ScrawlDebugSession } = require('./debug');

let diagnostics;
let status;
let typingTimer;
let warnedMissing = false;

function isFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch (e) {
    return false;
  }
}

function onPath(name) {
  const dirs = (process.env.PATH || '').split(path.delimiter);
  for (const d of dirs) {
    const p = path.join(d, name);
    if (isFile(p)) return p;
  }
  return null;
}

function scrawlPath(doc) {
  const configured = vscode.workspace.getConfiguration('spaceCoder').get('scrawlPath') || '';
  return core.findScrawl(
    {
      configured: configured.replace(/^~(?=$|\/|\\)/, os.homedir()),
      home: os.homedir(),
      platform: process.platform,
      workspaceFolders: (vscode.workspace.workspaceFolders || []).map((f) => f.uri.fsPath),
      fileDir: doc ? path.dirname(doc.uri.fsPath) : undefined,
    },
    isFile,
    onPath
  );
}

async function missingScrawl() {
  if (warnedMissing) return;
  warnedMissing = true;
  const pick = await vscode.window.showWarningMessage(
    'Space Coder can\'t find the scrawl program. Copy the one for your computer from the bin folder in litesloth-scrawl to scrawl (or build it with go build -o scrawl ./cmd/scrawl), then show Space Coder where it is.',
    'Find scrawl'
  );
  if (pick === 'Find scrawl') vscode.commands.executeCommand('spaceCoder.setPath');
}

function setStatus(text, tooltip) {
  status.text = text;
  status.tooltip = tooltip || 'LiteSloth Space Coder';
  status.show();
}

// Checks a document with `scrawl check --json` and underlines the mistake.
function check(doc, whileTyping) {
  if (!doc || doc.languageId !== 'scrawl' || doc.uri.scheme !== 'file') return;
  const scrawl = scrawlPath(doc);
  if (!scrawl) {
    setStatus('$(rocket) Space Coder: scrawl not found', 'Click to show Space Coder where scrawl is');
    status.command = 'spaceCoder.setPath';
    missingScrawl();
    return;
  }
  status.command = 'spaceCoder.check';
  let target = doc.uri.fsPath;
  let tmp;
  if (whileTyping && doc.isDirty) {
    // brought-in files are found next to the real file, so only check the
    // unsaved text on its own when it doesn't bring in other files
    if (/^\s*bring\s+in\s+"/m.test(doc.getText())) return;
    tmp = path.join(os.tmpdir(), 'spacecoder-' + process.pid + '-' + path.basename(target));
    fs.writeFileSync(tmp, doc.getText());
    target = tmp;
  }
  cp.execFile(scrawl, ['check', '--json', target], { timeout: 15000 }, (err, stdout) => {
    if (tmp) fs.rm(tmp, () => {});
    if (err && !stdout) {
      setStatus('$(warning) Space Coder', 'scrawl could not run: ' + err.message);
      return;
    }
    const r = core.parseCheck(stdout, target, doc.uri.fsPath);
    diagnostics.clear();
    if (r.ok) {
      setStatus('$(rocket) Space Coder $(check) No mistakes');
      return;
    }
    const uri = vscode.Uri.file(r.file);
    const lineIdx = r.line - 1;
    let range = new vscode.Range(lineIdx, 0, lineIdx, 1000);
    if (r.file === doc.uri.fsPath && lineIdx < doc.lineCount) {
      const text = doc.lineAt(lineIdx);
      range = new vscode.Range(lineIdx, text.firstNonWhitespaceCharacterIndex, lineIdx, text.text.length);
    }
    const d = new vscode.Diagnostic(range, r.message, vscode.DiagnosticSeverity.Error);
    d.source = 'Space Coder';
    diagnostics.set(uri, [d]);
    setStatus('$(rocket) Space Coder $(error) 1 mistake', r.message);
  });
}

function terminal() {
  let t = vscode.window.terminals.find((x) => x.name === 'Space Coder');
  if (!t) t = vscode.window.createTerminal({ name: 'Space Coder' });
  t.show();
  return t;
}

async function inTerminal(verb) {
  const ed = vscode.window.activeTextEditor;
  if (!ed || ed.document.languageId !== 'scrawl') {
    vscode.window.showInformationMessage('Open a .scrawl file first.');
    return;
  }
  if (ed.document.isUntitled) {
    vscode.window.showInformationMessage('Save the file first (with a name ending in .scrawl).');
    return;
  }
  await ed.document.save();
  const scrawl = scrawlPath(ed.document);
  if (!scrawl) {
    warnedMissing = false;
    return missingScrawl();
  }
  const t = terminal();
  const dir = path.dirname(ed.document.uri.fsPath);
  t.sendText('cd ' + core.quoteForShell(dir, process.platform));
  t.sendText(core.runCommand(scrawl, verb, ed.document.uri.fsPath, process.platform));
}

async function showGo() {
  const ed = vscode.window.activeTextEditor;
  if (!ed || ed.document.languageId !== 'scrawl') return;
  await ed.document.save();
  const scrawl = scrawlPath(ed.document);
  if (!scrawl) return missingScrawl();
  cp.execFile(scrawl, ['go', ed.document.uri.fsPath], { timeout: 15000 }, async (err, stdout, stderr) => {
    if (err) {
      vscode.window.showErrorMessage(String(stderr || err.message).trim());
      return;
    }
    const doc = await vscode.workspace.openTextDocument({ language: 'go', content: stdout });
    vscode.window.showTextDocument(doc, vscode.ViewColumn.Beside);
  });
}

// Tidies the whole file with `scrawl tidy -` (used by Format Document and Tidy Up).
function tidyEdits(doc) {
  return new Promise((resolve) => {
    const scrawl = scrawlPath(doc);
    if (!scrawl) {
      missingScrawl();
      resolve([]);
      return;
    }
    const text = doc.getText();
    const child = cp.execFile(scrawl, ['tidy', '-'], { timeout: 15000 }, (err, stdout) => {
      if (err) {
        vscode.window.setStatusBarMessage('$(warning) Space Coder: fix the underlined mistake first, then tidy up', 5000);
        resolve([]);
        return;
      }
      if (stdout === text.replace(/\r\n/g, '\n')) {
        resolve([]);
        return;
      }
      const all = new vscode.Range(doc.positionAt(0), doc.positionAt(text.length));
      resolve([vscode.TextEdit.replace(all, stdout)]);
    });
    child.stdin.end(text);
  });
}

async function setPath() {
  const picked = await vscode.window.showOpenDialog({
    canSelectMany: false,
    openLabel: 'Use this scrawl',
    title: 'Where is the scrawl program? (inside your litesloth-scrawl folder)',
    defaultUri: vscode.Uri.file(path.join(os.homedir(), 'Downloads', 'litesloth-scrawl')),
  });
  if (!picked || !picked[0]) return;
  await vscode.workspace.getConfiguration('spaceCoder').update('scrawlPath', picked[0].fsPath, vscode.ConfigurationTarget.Global);
  warnedMissing = false;
  vscode.window.showInformationMessage('Space Coder will use ' + picked[0].fsPath);
  check(vscode.window.activeTextEditor && vscode.window.activeTextEditor.document);
}

// Starts the debugger on the open .scrawl file (the bug button, or F5).
async function debugFile() {
  const ed = vscode.window.activeTextEditor;
  if (!ed || ed.document.languageId !== 'scrawl') {
    vscode.window.showInformationMessage('Open a .scrawl file first.');
    return;
  }
  vscode.debug.startDebugging(vscode.workspace.getWorkspaceFolder(ed.document.uri), {
    type: 'scrawl',
    name: 'Debug ' + path.basename(ed.document.uri.fsPath),
    request: 'launch',
    program: ed.document.uri.fsPath,
  });
}

const debugConfigs = {
  // F5 with no launch.json: debug the open file
  async resolveDebugConfiguration(folder, config) {
    if (!config.type && !config.request && !config.name) {
      const ed = vscode.window.activeTextEditor;
      if (ed && ed.document.languageId === 'scrawl') {
        config.type = 'scrawl';
        config.name = 'Debug ' + path.basename(ed.document.uri.fsPath);
        config.request = 'launch';
        config.program = ed.document.uri.fsPath;
      }
    }
    if (!config.program) {
      vscode.window.showInformationMessage('Open a .scrawl file first, then press F5.');
      return undefined;
    }
    if (config.program === '${file}' && vscode.window.activeTextEditor) config.program = vscode.window.activeTextEditor.document.uri.fsPath;
    const doc = vscode.workspace.textDocuments.find((d) => d.uri.fsPath === config.program);
    if (doc) {
      if (doc.isUntitled) {
        vscode.window.showInformationMessage('Save the file first (with a name ending in .scrawl).');
        return undefined;
      }
      await doc.save();
    }
    config.scrawlPath = scrawlPath(doc);
    if (!config.scrawlPath) {
      warnedMissing = false;
      missingScrawl();
      return undefined;
    }
    return config;
  },
};

function activate(context) {
  diagnostics = vscode.languages.createDiagnosticCollection('scrawl');
  status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  status.command = 'spaceCoder.check';
  setStatus('$(rocket) Space Coder');

  context.subscriptions.push(
    diagnostics,
    status,
    vscode.commands.registerCommand('spaceCoder.run', () => inTerminal('run')),
    vscode.commands.registerCommand('spaceCoder.debug', debugFile),
    vscode.debug.registerDebugConfigurationProvider('scrawl', debugConfigs),
    vscode.debug.registerDebugAdapterDescriptorFactory('scrawl', {
      createDebugAdapterDescriptor() {
        return new vscode.DebugAdapterInlineImplementation(new ScrawlDebugSession());
      },
    }),
    vscode.commands.registerCommand('spaceCoder.build', () => inTerminal('build')),
    vscode.commands.registerCommand('spaceCoder.test', () => inTerminal('test')),
    vscode.commands.registerCommand('spaceCoder.check', () => {
      const ed = vscode.window.activeTextEditor;
      if (ed) check(ed.document, false);
    }),
    vscode.commands.registerCommand('spaceCoder.showGo', showGo),
    vscode.commands.registerCommand('spaceCoder.setPath', setPath),
    vscode.commands.registerCommand('spaceCoder.tidy', () => vscode.commands.executeCommand('editor.action.formatDocument')),
    vscode.languages.registerDocumentFormattingEditProvider('scrawl', { provideDocumentFormattingEdits: tidyEdits }),
    vscode.workspace.onDidOpenTextDocument((d) => check(d, false)),
    vscode.workspace.onDidSaveTextDocument((d) => check(d, false)),
    vscode.workspace.onDidCloseTextDocument((d) => diagnostics.delete(d.uri)),
    vscode.window.onDidChangeActiveTextEditor((ed) => ed && check(ed.document, false)),
    vscode.workspace.onDidChangeTextDocument((e) => {
      if (e.document.languageId !== 'scrawl') return;
      if (!vscode.workspace.getConfiguration('spaceCoder').get('checkWhileTyping')) return;
      clearTimeout(typingTimer);
      typingTimer = setTimeout(() => check(e.document, true), 700);
    }),
    vscode.languages.registerHoverProvider('scrawl', {
      provideHover(doc, pos) {
        const range = doc.getWordRangeAtPosition(pos, /[A-Za-z_][A-Za-z0-9_]*/);
        if (!range) return null;
        const text = core.hoverFor(doc.getText(range));
        return text ? new vscode.Hover(new vscode.MarkdownString(text), range) : null;
      },
    })
  );

  for (const ed of vscode.window.visibleTextEditors) check(ed.document, false);
}

function deactivate() {}

module.exports = { activate, deactivate };
