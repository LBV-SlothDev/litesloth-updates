# Changelog

## 0.10.0
For Scrawl 0.11: colors, hover help and the shortcut `secure` for fingerprints and digital signatures (secure.hash, secure.keys, secure.sign, secure.check, secure.public, secure.random).

## 0.9.0
For Scrawl 0.10: Run Tests (right-click, or the Command Palette) runs `scrawl test`. Colors, hover help and shortcuts for Test., expect, expect problem (test, expectproblem), and the new page parts checkbox, notes, number, choice and table (checkbox, choice, table), and when changed. Mistakes found by the new checks (like a misspelled part of a Thing) are underlined while you type.

## 0.8.1
Colors and hover help for Scrawl 0.9.3: when chosen, when dragged, when dropped, page.notify.

## 0.8.0
Step-through debugger for Scrawl 0.9: press F5 (or the bug button next to Run) to stop at breakpoints, step line by line, see every name and open lists and things in the Variables view, and stop where a problem happens. Run moved to Cmd+Enter (Ctrl+Enter). Colors, hover help and shortcuts for channels (channel), `is a` Things (thingisa) and `.kind ()`.

## 0.7.0
For Scrawl 0.8: colors, hover help and shortcuts for SQLite databases (`as sqlite`, shortcut sqlite) and `db.sql` (shortcut sql).

## 0.6.0
For Scrawl 0.7: colors, hover help and shortcuts for app mode (app), tabs, charts, maps, things' own commands (thingcommand), at the same time (together), folder. and my.

## 0.5.0
Tidy Up (right-click, Shift+Alt+T, or Format Document) lines your code up neatly using `scrawl tidy`. raw go: and raw python: blocks are colored as Go and Python, with hover help and the shortcuts rawgo and rawpython.

## 0.4.0
Everyday words (Scrawl 0.5): colors and hover help for lookup, random., time., and new actions like .shuffle, .total, .average, .commas, .until and .ago. New shortcuts: lookup, dice, countdown.

## 0.3.0
Website words: Part., show subheading / box / nav / footer / video / html / secret, bring in script / stylesheet / accounts, account., server.files.

## 0.2.0
Web page words: colors, hover help and shortcuts for Page., Style., show, remember, when, go to.

## 0.1.0
First version: colors, LiteSloth Space theme, Run / Build / Show Go, mistakes underlined while typing, hover help, typing shortcuts.
